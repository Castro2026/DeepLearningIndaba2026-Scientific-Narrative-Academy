# The 3-Sentence Abstract Template — LaTeX / Overleaf

**Mastering the Scientific Narrative** · Deep Learning Indaba 2026 · Skill Session
Castro Gbêmêmali Hounmenou — University of Labé / CERFIG, Guinea

This is the template you write in during the hands-on exercise. You leave the
session with a real LaTeX document you can keep developing into a submission.

---

## Open it in 20 seconds (during the session)

**Option A — Overleaf (recommended).** Scan the QR code on any slide, or go to:

> **Copyable Overleaf link:**
> `https://www.overleaf.com/docs?snip_uri=https://github.com/Castro2026/DeepLearningIndaba2026-Scientific-Narrative-Academy/raw/main/latex-template/indaba-narrative-template.zip`

Overleaf will import the project and immediately make **your own private copy** —
you are not editing anyone else's file. Click **Recompile** and you should see a
6-page PDF.

> If you already have the project open and it says *Read only*, use
> **Menu → Copy Project**. Now it is yours.

**Option B — No internet / no laptop.** Take the printed copy from the front of
the room, write your three sentences on paper, and type them into Overleaf later.
The exercise is the thinking, not the typing.

**Option C — Your own machine.**

```bash
git clone https://github.com/Castro2026/DeepLearningIndaba2026-Scientific-Narrative-Academy.git
cd DeepLearningIndaba2026-Scientific-Narrative-Academy/latex-template
latexmk -pdf main.tex
```

---

## What you actually do today

You touch **three things**. Nothing else.

### 1. Your working title — your 15-word promise

```latex
\workingtitle{CropGuard: an offline, quantized detector for cassava disease
on low-end phones in Guinea and Nigeria}
```

Three formulas that work:

| Formula | Example |
|---|---|
| `[Method]: [what it does] for [problem]` | *AgroNet: Lightweight Crop-Disease Detection for Offline Mobile Use* |
| `[Question or claim as a hook]` | *Do Multilingual Models Understand West African Languages?* |
| `[Resource] + [scale/context]` | *NaijaVoices: a 500-Hour Speech Corpus for Nigerian Languages* |

**Test:** could a stranger guess your method, your problem **and** your context
from the title alone?

### 2. Your 3-sentence abstract — the exercise

```latex
\begin{threesentenceabstract}
  \context{ ... }   % S1 — Context + Gap
  \method{ ... }    % S2 — Your method
  \impact{ ... }    % S3 — Results + Impact
\end{threesentenceabstract}
```

The rules, enforced by nothing but your own honesty:

- **Sentence 1** must contain a **place** and a **number**.
- **Sentence 2** must contain the **thing you built** and **what is new** about it.
- **Sentence 3** must contain a **metric**, a **value**, and a **named baseline**.
- No sentence may contain *very*, *novel*, *promising* or *revolutionary*
  without a number sitting next to it.

**Judge yourself with one question:** could a stranger fund this project after
reading your three sentences?

### 3. Pick a scenario (or use your own research)

`\scenariocards` prints the four tracks: **climate**, **agriculture**,
**health**, **local languages**. Your own research beats all four — use it if
you have it.

---

## What happens after the session

Everything below the abstract is a full paper skeleton, pre-wired with the
checklist from the deck: the Introduction funnel, the Heilmeier Catechism, a
`booktabs` results table with a trade-off column, the dataset card, the
Limitations section, and a Reproducibility statement.

Each section carries a **Reviewer's Lens** box — the one question a reviewer
actually asks of that section — and **Coach** notes.

### When you are ready to submit, change one word

```latex
\usepackage[draft]{indaba_narrative}   % coached mode — boxes visible (today)
\usepackage[final]{indaba_narrative}   % clean mode — all scaffolding vanishes
```

In `[final]` mode the working-title box, the coloured abstract box, the
Reviewer's Lens boxes, the scenario cards, the dataset card and every Coach note
disappear, and your three sentences run together as an ordinary abstract
paragraph. Nothing else moves.

### Then drop in the real venue style

This template deliberately does **not** ship the official NeurIPS or ICLR style
files — each venue distributes its own, and they change every year. When your
venue is chosen:

1. Download the official style from the venue's call for papers
   (e.g. `neurips_2026.sty`, `iclr2026_conference.sty`).
2. Put it next to `main.tex`.
3. Swap the document class / style line, keep `\usepackage[final]{indaba_narrative}`
   if you still want the scaffolding available while drafting, and move your
   title, authors, abstract and sections across. The abstract is already the
   right shape.

---

## Files

| File | What it is |
|---|---|
| `main.tex` | **Your document.** Start here. |
| `indaba_narrative.sty` | The scaffolding: working title, 3-sentence abstract environment, Reviewer's Lens, scenario cards, dataset card. MIT licensed — reuse it. |
| `references.bib` | Starter bibliography: the papers behind this session. |
| `README.md` | This file. |

## The starter bibliography

Already in `references.bib`, already citable:

- **Keshav (2007)**, *How to Read a Paper* — the 3-Pass method. Two pages. Read it tonight.
- **Vaswani et al. (2017)**, *Attention Is All You Need* — the paper we scanned live.
- **Odounfa, Hounmenou et al. (2025)**, chili pepper disease detection in Benin,
  *Discover Artificial Intelligence* 5:315 — open access. An African paper, published.
- **Tahi, Houndji, Hounmenou & Glèlè Kakaï (2024)**, maize yield in Benin, *IJ-AI*
  13(4) — first shown at a NeurIPS 2022 workshop. An African paper, at NeurIPS.
- **Wilkinson et al. (2016)**, the FAIR principles.
- **Gebru et al. (2021)**, *Datasheets for Datasets*.

Do not type BibTeX by hand. Let Zotero or Mendeley export it for you.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| Overleaf says **Read only** | Menu → **Copy Project**. |
| `File 'indaba_narrative.sty' not found` | The `.sty` must sit in the same folder as `main.tex`. If you uploaded only `main.tex`, upload the `.sty` too. |
| Citations show as `[?]` | Recompile twice — BibTeX needs a second pass. On Overleaf, just press Recompile again. |
| Bibliography is empty | Check that `references.bib` uploaded, and that you have at least one `\citep{...}` or `\nocite{...}`. |
| Accented characters break | Keep the file saved as UTF-8; the template already loads `inputenc` and `fontenc`. |

---

## Licence

MIT — see `LICENSE`. Use it, fork it, teach with it, give it to your students.
If it helps you publish, that is the entire point.

*Master the scientific narrative — so Africa tells its own research stories.*
